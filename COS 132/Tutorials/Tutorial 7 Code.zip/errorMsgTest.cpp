#include <iostream>


int main() {
    int position;
    std::cout << "Enter the position in Fibonacci series: ";
    std::cin >> position;
    std::cout << "The Fibonacci number is " << fibonacci(postion) << std::endl;  // Error: Typo in variable name
    return 0;
}

// Intentional errors are included for debugging practice
int fibonacci(int n) {
    if (n = 0) {  // Error: Incorrect use of assignment operator
        return 0;
    }
    elseif (n == 1) { // Error: Incorrect keyword usage
        return 1;
    }
    return fibonnaci(n - 1) + fibonacci(n - 2);  // Error: Typo in function name
}
