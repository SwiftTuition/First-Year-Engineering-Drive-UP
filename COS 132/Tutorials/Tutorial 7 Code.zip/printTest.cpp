#include <iostream>

int factorial(int n) {
    std::cout << "\033[1;34m" << "factorial called with n = " << n << "\033[0m" << std::endl; // Debug print statement in blue
    if (n <= 1) {
        std::cout << "\033[1;32m" << "Base case reached with n = " << n << ", returning 1" << "\033[0m" << std::endl; // Base case debug in green
        return 1;
    }
    int result = n * factorial(n - 1);
    std::cout << "\033[1;35m" << "Returning " << result << " for factorial of " << n << "\033[0m" << std::endl; // Debugging return value in magenta
    return result;
}

int main() {
    int num = 5;
    std::cout << "\033[1;33m ----- ------ ----- \n Starting factorial\n ----- ------ ----- \n \033[0m" << std::endl; // Starting message in cyan
    
    int factNum = factorial(num);
    std::cout << "\033[1;36m \nThe factorial of " << num <<" is " << factNum <<"\033[0m" << std::endl; // Result in yellow
    
    std::cout << "\033[1;33m \n ----- ------ ----- \n End of factorial\n ----- ------ ----- \n  \033[0m" << std::endl; // End message in cyan
    return 0;
}
