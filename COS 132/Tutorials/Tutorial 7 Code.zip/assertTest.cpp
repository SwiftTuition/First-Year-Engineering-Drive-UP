#include <iostream>
#include <cassert>

// Factorial function that calculates the factorial of a non-negative integer.
// Precondition: n must be non-negative.
// Postcondition: Result must not overflow the maximum value representable by `unsigned long long`.
int factorial(int n) {
    assert(n >= 0); // Precondition: n must be non-negative.

    int result = 1;
    int i = 1;

    while ( i <= n ) {
        result *= i;
        assert(result >= i); // Postcondition check at each step to detect overflow.
        i++;
    }

    return result;
}

int main() {
    // Test the factorial function with various inputs.
    
    int fact5 = factorial(5);
    std::cout << "Factorial of 5 is " << fact5 << std::endl;
    //assert(fact5 == 120);

    int fact4 = factorial(4);
    std::cout << "Factorial of 4 is " << fact4 << std::endl;
    //assert(fact4==24);

    // Uncommenting the following line should cause an assertion failure if the input is invalid.
    int factNeg = factorial(-1);
    std::cout << "Factorial of -1 is " << factNeg << std::endl;

    return 0;
}
