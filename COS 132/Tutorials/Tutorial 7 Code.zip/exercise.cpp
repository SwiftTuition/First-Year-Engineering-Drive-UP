#include <iostream>

float calculate_bill( char meal, float tip ){
	float total = 0.3 ;
	switch (meal ) {
    case 'A':
        total += 17; break;
    case 'B':
        total += 89; break;
    case 'C':
        total += 13; break;
    default:
        total += 9; break;
   	 }
	return total + tip;
}

int main() {
    // Add test cases here
    // Use asserts to see which cases fail
    // Do not just fix the function - the point is to design test cases to find the bugs
    return 0;
}