#include "BinaryTree.h"
using namespace std;

void BinaryTree::insertNode(int data) {
    Node *newNode = new Node(data);
    if (root == NULL) {
        root = newNode;
        return;
    } else {
        recursiveInsert(root, newNode);
    }
}

void BinaryTree::recursiveInsert(Node *curr, Node *newNode) {
    if (newNode->data == curr->data) {
        delete newNode;
        return;
    } else if (newNode->data > curr->data) {
        if (curr->right == NULL) {
            curr->right = newNode;
        } else {
            recursiveInsert(curr->right, newNode);
        }
    } else {
        if (curr->left == NULL) {
            curr->left = newNode;
        } else {
            recursiveInsert(curr->left, newNode);
        }
    }
}

bool BinaryTree::searchNode(int data) {
    if (root == NULL) {
        cout << "Tree is empty." << endl;
        return false;
    } else {
        recursiveSearch(root, data);
    }
}

bool BinaryTree::recursiveSearch(Node *curr, int data) {
    if (curr == NULL) {
        cout << "Data not found." << endl;
        return false;
    }
    
    if (curr->data == data) {
        cout << "Current Node value is: " << curr->data 
        << ", the required value is: " << data << std::endl;
        return true;
    } 

    cout << "Current node value is: " << curr->data << ".";
    
    if (data < curr->data) {
        cout << "The desired data is less than the current node’s value, searching down the left child..." <<  endl;
        return recursiveSearch(curr->left, data);
    } else {
        cout << "The desired data is greater than the current node’s value, searching down the right child..." <<  endl;
        return recursiveSearch(curr->right, data);
    }

    return false;
}