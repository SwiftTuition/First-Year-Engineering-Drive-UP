#include <iostream>

using namespace std;

int main(){
    cout<<"Hello, my name is uXXXXXXXX. Welcome to Code Brew."<<endl<<"How can I help you today?"<<endl;
}
