#include <iostream>
#include <string>
using namespace std;

int main() {

    // DO PART 1 HERE
    string employeeOfTheMonth = "Jamie";
    int hoursWorked = 40;
    float hourlyWage = 20.50;
    float weeklyBonus = 200.00;
    float totalTips = 150.50;
    bool workedOverTime = true;
    
    // DO NOT CHANGE THE COUT STATEMENTS
    cout << "###\n";
    cout << "Employee of the Month: " << employeeOfTheMonth << endl ;
    cout << "###\n";
    cout << "Hours worked last week: " << hoursWorked << endl;
    cout << "###\n";
    cout<< "Hourly wage rate: R" << hourlyWage << endl;
    cout << "###\n";
    cout<< "Weekly bonus: R" <<weeklyBonus <<endl;
    cout << "###\n";
    cout<<"Total tips: R"<<totalTips<<endl;
    cout << "###\n";
    cout << "Overtime: " << workedOverTime <<endl;
    cout << "###\n";

    // DO PART 2 HERE
    hoursWorked += 2;
    float totalWage = hoursWorked * hourlyWage;
    float totalEarnings = totalWage + weeklyBonus + totalTips;
    cout << hoursWorked << endl;
    cout << totalWage << endl;
    cout << totalEarnings << endl;



    cout << "###\n"; //DO NOT CHANGE
    return 0;
}
