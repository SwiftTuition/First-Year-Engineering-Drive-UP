#include <iostream>
#include "MonitoringSystem.h"
using namespace std;
// Function implementations here

void monitorAndAdjust(float temperature, float pressure, float humidity) {
  adjustHumidity(humidity, temperature, pressure);
  adjustPressure(pressure, temperature, humidity);
  adjustTemperature(temperature, humidity, pressure);
}
