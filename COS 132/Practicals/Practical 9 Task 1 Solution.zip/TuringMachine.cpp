#include "TuringMachine.h"
// Function implementations will go here

void initializeMachine(char tape[], int &head, const string &currentState, int tapeSize)
{
  head = 0;

  for (int i = 0; i < tapeSize; i++)
  {
    if (tape[i] != '_')
    {
      head = i;
    }
  }
}

bool matchRule(const string &currentState, const char &currentSymbol, string rules[][5], int numRules, string &newState, char &newSymbol, string &move)
{
  for (int i = 0; i < numRules; ++i)
  {
    if (rules[i][1][0] == currentSymbol && rules[i][0] == currentState)
    {
      newSymbol = rules[i][3][0];
      newState = rules[i][2];
      move = rules[i][4][0];
      return true;
    }
  }
  return false;
}

void applyRule(char tape[], int &head, const string &newState, string &currentState, const char &newSymbol, const string &move, int tapeSize)
{
  currentState = newState;
  tape[head] = newSymbol;

  if (move[0] == 'L' && head != 0)
  {
    head -= 1;
  }
  else if (move[0] == 'R' && head < tapeSize - 1)
  {
    head += 1;
  }
}

bool checkFinalState(const string &currentState)
{
  if (currentState == "accept" || currentState == "reject")
  {
    return true;
  }

  else
  {
    return false;
  }
}

void printOutput(const char tape[], const string &currentState, int tapeSize)
{
  cout << "Final tape: ";
  for (int i = 0; i < tapeSize; ++i)
  {
    cout << tape[i];
  }
  cout << endl;

  cout << "Machine ended in state: " << currentState << endl;
}

void simulateTuringMachine(char tape[], string rules[][5], int numRules, int tapeSize)
{
  int head = 0;
  string currentState = "start";
  initializeMachine(tape, head, currentState, tapeSize);

  bool finalState = checkFinalState(currentState);
  while (finalState == false)
  {
    string newState;
    char newSymbol;
    string move;

    bool ruleFound = matchRule(currentState, tape[head], rules, numRules, newState, newSymbol, move);
    if (ruleFound == true)
    {
      applyRule(tape, head, newState, currentState, newSymbol, move, tapeSize);
    }
    else
    {
      break;
    }
  }

  printOutput(tape, currentState, tapeSize);
}
