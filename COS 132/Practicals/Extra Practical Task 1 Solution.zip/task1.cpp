#include <string>
#include <iostream>
using namespace std;

int main(){
    cout << "###" << endl;

    //add your code here
    cout << "Good morning, Code Brew team! This is your manager." << endl;
    cout << "Let's make today another day of great code and great coffee!" << endl;
    
    cout << "###" << endl;
    return 0;
}