#include "TreasureMap.h"
// Implement the functions to find the treasure

bool findTreasure(char map[ROWS][COLS], int jumps[], int jumpsLength, char *result)
{
    int resultIndex = 0;

    for (int i = 0; i < jumpsLength; i++)
    {
        int row = (jumps[i]) / COLS;
        int col = (jumps[i]) % COLS;

        if (map[row][col] == 'X')
        {
            result[resultIndex] = '\0';
            return true;
        }
        
        else if (map[row][col] != '-')
        {
            result[resultIndex]= map[row][col];
            resultIndex += 1;
        }
    }

    result[resultIndex] = '\0';
    return false;
}