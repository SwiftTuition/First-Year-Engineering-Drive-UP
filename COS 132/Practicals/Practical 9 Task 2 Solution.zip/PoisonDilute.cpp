#include "PoisonDilute.h"
// Implement the functions to find the nth largest amount needed to dilute the poison

int *findNthLargest(int *arr, int size, int n, int *largest)
{
  int topN[n];
  for (int i = 0; i < n; i++)
  {
    int indexOfMax = 0;
    for (int j = 0; j < size; j++)
    {
      if (arr[j] > arr[indexOfMax])
      {
        indexOfMax = j;
      }
    }

    largest[i] = arr[indexOfMax];
    arr[indexOfMax] = 0;
  }

  for (int k = 0; k < n - 1; k++)
  {
    for (int l = k + 1; l < n; l++)
    {
      if (largest[k] > largest[l])
      {
        int temp = largest[k];
        largest[k] = largest[l];
        largest[l] = temp;
      }
    }
  }

  return largest;
}