// Online C++ compiler to run C++ program online
#include <iostream>
using namespace std;

const char *myArray = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

int findIndex(char c)
{
    for (int i = 0; i < 64; i++)
    {
        if (c == myArray[i])
        {
            return i;
        }
    }

    return -1;
}

void decodeBase64(const char encoded[], char decoded[], int encodedLength)
{
    int index = 0;
    for (int i = 0; i < encodedLength; i += 4)
    {
        int idx0 = findIndex(encoded[i]);
        int idx1 = findIndex(encoded[i + 1]);
        int idx2 = findIndex(encoded[i + 2]);
        int idx3 = findIndex(encoded[i + 3]);

        char byte1 = (idx0 * 4) + (idx1 / 16);
        char byte2 = ((idx1 % 16) * 16) + (idx2 / 4);
        char byte3 = ((idx2 % 4) * 64) + idx3;

        decoded[index] = byte1;
        decoded[index + 1] = byte2;
        decoded[index + 2] = byte3;

        index += 3;
    }
    decoded[index] = '\0';
}