//NumberUtils.cpp
// Function implementations for number utilities will go here

#include "NumberUtils.h"
#include <cmath>

int reverseInteger(int number) {
  int reversed = 0;
  while (number != 0) {
    int lastDigit = number % 10;
    reversed = reversed * 10 + lastDigit;
    number /= 10;
  }
  return reversed;
}

bool isPalindrome(int number) {
  int reversed = reverseInteger(number);
  return reversed == number;
}

int sumOfDigits(int number) {
  int sum = 0;
  while (number != 0) {
    int lastDigit = number % 10;
    sum += lastDigit;
    number /= 10;
  }
  return sum;
}

int getNumberOfDigits(int number) {
  int digits = 0;
  while (number != 0) {
    digits++;
    number /= 10;
  }
  return digits;
}

bool isArmstrong(int number) {
  int original = number;
  int digits = getNumberOfDigits(number);
  int sum = 0;

  while (number != 0) {
    int lastDigit = number % 10;
    sum += pow(lastDigit, digits);
    number /= 10;
  }

  return sum == original;
}

bool isPerfect(int number) {
  int sum = 0;
  for (int i = 1; i < number; i++) {
    if (number % i == 0) {
      sum += i;
    }
  }

  return sum == number;
}