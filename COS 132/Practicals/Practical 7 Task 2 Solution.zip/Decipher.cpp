//Decipher.cpp
#include <iostream>
#include "NumberUtils.h"
#include "StringUtils.h"
#include "Decipher.h"
using namespace std;
// Function implementations for deciphering will go here
char shiftCharacter(char input, int shift) {
  char base = (islower(input)) ? 'a' : 'A';
  int offset = input - base;
  int shiftedIndex = (offset + shift + 26) % 26;
  char result = shiftedIndex + base;
  return result;
}

string decipher(int num1, string str1, int num2, string str2) {
  if (isPalindrome(num1) == true){
    str1 = returnDecodedString(str1, sumOfDigits(num1));
  }

  if (isArmstrong(num2) == true || isPerfect(num2) == true) {
    str2 = returnDecodedString(str2, sumOfDigits(num2));
  
  }

  string result = str1 + "-" + str2;
  return result;
}