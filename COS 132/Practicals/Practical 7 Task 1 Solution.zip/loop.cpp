#include "loop.h"

void printCollat(int num){
    //Add your implementation here    
    if (num == 1){
        cout << num << endl;
    }

    else {
        cout << num << endl;

        if (num % 2 != 0){
            num = 3 * num + 1;
            printCollat(num);
        }

        else {
            num = num/2;
            printCollat(num);
        }
        
    }
}

void printCollatz(int num){
    //Add your implementation here

    cout << "Starting from " << num << endl;
    
    if (num == 1){
        cout << num << endl;
    }

    else {
        cout << num << endl;

        if (num % 2 != 0){
            num = 3 * num + 1;
            printCollat(num);
        }

        else {
            num = num/2;
            printCollat(num);
        }
        
    }
}

void printSquares(int n){
    //Add your implementation here

    for ( int i = 1; i <= n; i++){
        cout << "Square of " << i << " is " << i * i << endl;
    }
}

void printDiamond(int halfSize){
    //Add your implementation here

    for (int i = 1; i <= halfSize; i++){
       
       for ( int j = 1; j <= halfSize - i; j++){
        cout << " ";
       }

       for (int j = 1; j <= 2 * i - 1; j++){
        cout << "*";
       }

       cout << endl;
    }

    for (int i = halfSize - 1; i >= 1; i--){
       
       for ( int j = 1; j <= halfSize - i; j++){
        cout << " ";
       }

       for (int j = 1; j <= 2 * i - 1; j++){
        cout << "*";
       }

       cout << endl;
       
    }
}