#include "DigitBasedPasswordCracker.h"


int crackPassswordPerDigit(int password, int numDigits){
    // Implement here

    int guessedDigit = 0;

    int numDigitsLeftToGuess = numDigits;

    int currentPasswordGuess = 0;

    return crackDigit(password, guessedDigit, numDigitsLeftToGuess, currentPasswordGuess);
}

// Modified processDigitGuess function
int processDigitGuess(int password, int guessedDigit, int numDigitsLeftToGuess, int currentPasswordGuess) {
    // Implement here
   int digit = (password / (int)pow(10, numDigitsLeftToGuess - 1) % 10);

    if (guessedDigit == digit) {

        currentPasswordGuess += guessedDigit * (int)pow(10, numDigitsLeftToGuess - 1);

        return crackDigit(password, 0, numDigitsLeftToGuess - 1, currentPasswordGuess);
        }
        
        else {
        return crackDigit(password, (guessedDigit + 1) % 10, numDigitsLeftToGuess, currentPasswordGuess);
        }
}


// Modified crackDigit fnction to use processDigitGuess
int crackDigit(int password, int guessedDigit, int numDigitsLeftToGuess, int currentPasswordGuess) {
    // Implement here

    printCurrentGuess(password, guessedDigit, numDigitsLeftToGuess, currentPasswordGuess);

    if (numDigitsLeftToGuess == 0) {
        return currentPasswordGuess;
    }
    else {
       return processDigitGuess(password, guessedDigit, numDigitsLeftToGuess, currentPasswordGuess);
    }
}
