#include "Comparisons.h"

bool isEqual(int a, int b) {
    // Implement here

    if ( a == b ) {
        return true;
    }

    else {
        return false;
    }
}

bool isLessThan(int a, int b) {
    // Implement here

    if ( a < b ) {
        return true;
    }

    else {
        return false;
    }
}

bool isGreaterThan(int a, int b){
    // Implement here

    if (a > b) {
        return true;
    }

    else {
        return false;
    }
}