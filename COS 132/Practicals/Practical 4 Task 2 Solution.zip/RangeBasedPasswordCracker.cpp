#include "RangeBasedPasswordCracker.h"

int decideAndSearch(int guess, int password, int low, int high) {
    // Implement here
    
    if (isLessThan(guess, password)) {
       return crackPassword(guess + 1, high, password);
    }
    else{
    return crackPassword(low, guess - 1, password);
    }
    
}


int crackPassword(int low, int high, int password) {
    // Implement here

    int midpoint = ( low + high ) / 2;

    printGuess(midpoint);

    if (isEqual(midpoint, password)) {
        return foundPassword(midpoint);
    }

    else {
        return decideAndSearch(midpoint, password, low, high);
    }
}
