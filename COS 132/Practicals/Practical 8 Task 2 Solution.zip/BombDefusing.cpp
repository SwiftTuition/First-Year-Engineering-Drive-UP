#include <iostream>
#include "BombDefusing.h"
// Implement the functions to defuse the bomb

int calculateSize(int *arr)
{
    int size = 0;

    while (arr[size] != -1)
    {
        size++;
    }

    return size;
}

void findPairs(int *arr, int size)
{
    bool *paired = new bool[size];

    for (int i = 0; i < size; i++)
    {
        paired[i] = false;
    }

    std::cout << "Starting wire comparison...\n";

    for (int i = 0; i < size; i++)
    {
        if (paired[i] == false)
        {

            for (int j = i + 1; j < size; j++)
            {
                if (arr[i] == arr[j] && paired[j] == false)
                {
                    paired[i] = true;
                    paired[j] = true;

                    std::cout << "Match found: Wire " << i + 1 << " and Wire " << j + 1 << " (Value: " << arr[i] << ") are a pair.\n";
                    break;
                }
            }

            if (paired[i] == false)
            {
                std::cout << "No match found for Wire " << i + 1 << " (Value: " << arr[i] << "). Cut this wire to defuse the bomb!\n";
            }
        }
    }
    delete[] paired;
}