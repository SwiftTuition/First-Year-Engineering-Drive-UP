#include <iostream>
#include "RoomLocater.h"
// Function implementations for finding the room will go here

int substringSearch(const char *str, const char *substr)
{
    const char *ptr1 = str, *ptr2 = substr;

    while (*ptr1 != '\0')
    {
        const char *start = ptr1;
        ptr2 = substr;

        while (*ptr2 != '\0' && *ptr1 == *ptr2)
        {
            ptr1++, ptr2++;
        }

        if (*ptr2 == '\0')
        {
            return start - str;
        }

        ptr1 = start + 1;
    }

    return -1;
}

void indexToChar(int index)
{
    char room = static_cast<char>(index);
    std::cout << "Floor: " << index << ", Room: " << room << std::endl;
}
