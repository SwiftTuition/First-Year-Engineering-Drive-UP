#include "Calculate.h"

double calculateContribution(double studentMark, int totalMark, double weight){
    //Implement function here
    double contribution = (studentMark/totalMark) * weight;
    return contribution;
}

double calculateIndividualWeight(double totalWeight, int numAssessments){
    //Implement function here
    double weight = totalWeight/numAssessments;
    return weight;
}