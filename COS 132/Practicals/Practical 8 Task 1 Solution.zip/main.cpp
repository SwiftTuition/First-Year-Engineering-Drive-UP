#include "task1.h"
#include <cassert>
#include <iostream>

using namespace std;

int main()
{

    // Add your tests here
    // You can use assert for tests

    cout << "Testing sortNumbers():\n";
    int a, b, c;
    
    a = -1; b = 39; c = 5;
    cout << "Original values: " << a << ", " << b << ", " << c << endl;
    sortNumbers(a, b, c);
    cout << "Using sortNumbers(): " << a << ", " << b << ", " << c << endl;

    a = 5000000; b = -102; c = 80;
    cout << "Original values: " << a << ", " << b << ", " << c << endl;
    sortNumbers(a, b, c);
    cout << "Using sortNumbers(): " << a << ", " << b << ", " << c << endl;

    cout << "Testing swap():\n";
    int x;
    int y;
    int * ptrA;
    int * ptrB;

    x = 10; 
    y = 20;
    ptrA = &x; ptrB = &y;
    cout << "Original values: ptrA=" << ptrA << ", *ptrA=" << *ptrA << ", ptrB=" << ptrB << ", *ptrB=" << *ptrB << endl;
    swap(&ptrA, &ptrB);
    cout << "Using swap(): ptrA=" << ptrA << ", *ptrA=" << *ptrA << ", ptrB=" << ptrB << ", *ptrB=" << *ptrB << endl;

    return 0;
}
