#include <iostream>
#include "task1.h"

using namespace std;

void sortNumbers(int& a, int& b, int& c) {
    int tempA = a, tempB = b, tempC = c;

    if (tempA > tempB) {

        if (tempA > tempC) {
            
            if (tempB > tempC){
                a = tempA;
                b = tempB;
                c = tempC;
            }

            else {
                a = tempA;
                b = tempC;
                c = tempB;
            }
            
        } 
        else {

            a = tempC;
            b = tempA;
            c = tempB;
        }
    } 
    
    else { 
        if (tempB > tempC) {

            if (tempA > tempC) {
                a = tempB;
                b = tempA;
                c = tempC;
            }

            else {
                a = tempB;
                b = tempC;
                c = tempA;
            }
            
        } 
        else {
            a = tempC;
            b = tempB;
            c = tempA;
        }
    }
}

void swap(int** ptrA, int** ptrB) {
    int * temp = *ptrA; 
    *ptrA = *ptrB;      
    *ptrB = temp;
}