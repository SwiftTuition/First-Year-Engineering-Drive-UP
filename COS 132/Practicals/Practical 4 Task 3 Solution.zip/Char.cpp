#include "Char.h"

char findNextChar(char current) 
{
    //Implement here

    return (current == 'z')? 'A' :(current == 'Z') ? 'a' :current + 1;
}



char findChar(char target, char current)
{
    //Implement here

    return (target == current)? current :findChar(target, findNextChar(current));
}
