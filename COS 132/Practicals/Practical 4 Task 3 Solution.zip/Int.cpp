#include "Int.h"

int findInt(int target, int current)
{
    //Implement here
    return (target == current) ?current :findInt(target, current + 1);
}


char convertChar(int character){
    //Implement here
    return static_cast<char>(character + '0');
}


