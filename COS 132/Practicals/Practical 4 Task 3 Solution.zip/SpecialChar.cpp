#include "SpecialChar.h"

char findSpecialChar(char target, int current)
{ 
    //Implement here
   
    return (target == current) ? current : findSpecialChar(target, current + 1);
}
