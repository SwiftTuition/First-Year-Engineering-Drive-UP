#include "DatabaseSearch.h"
using namespace std;

int searchDirectory() {
  int maxInt = 2147483647;
  double factorial = 1;
  int i = 1;
  for (i; factorial <= maxInt / i; i++) {
    factorial *= i;
  }
  cout << "Highest factorial without overflow is: " << (i - 1) << "! = " << factorial << endl;
  return findDatabaseFile(i);
}

bool isPrime(int num) {
  if (num <= 1) {
    return false;
  }
  else if (num <= 3) {
    return true;
  }
  
  else {
    for (int i = 2; i < num; i++) {
      if (num % i == 0) {
        return false;
      }
    }
    
        return true;   
  }
}

int findDatabaseFile(int maxNum) {
  int result;
  for (int i = 1; i <= maxNum; i++) {
    if (isPrime(i) == true) {
      cout << i << " is a prime number." << endl;
    } 
    
    else {
      int result = verifyDatabasePath(i);
      if (result != 0) {
        return result;
      }
    }
  }
  return 0;
}

int verifyDatabasePath(int dbIndex) {
  if (dbIndex == 12) {
    cout << "Verifying database path...C://home//CEO_Code//DB\n";
    return 80;
  } 
  
  else {
    cout << "Verifying database path...Incorrect index\n";
    return 0;
  }
}
